package com.dacatech.cotizaciones;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

class PdfMaker {
    private static final int W = 612, H = 792, M = 40, CW = W - 2 * M;
    private static final int INK = 0xFF111111, DARK = 0xFF0B1117;
    private final Context ctx;
    private final PdfDocument doc = new PdfDocument();
    private PdfDocument.Page page;
    private Canvas c;
    private int pages = 0;
    private float y;

    PdfMaker(Context ctx) { this.ctx = ctx; }

    private void newPage() {
        if (page != null) doc.finishPage(page);
        page = doc.startPage(new PdfDocument.PageInfo.Builder(W, H, ++pages).create());
        c = page.getCanvas();
        y = M;
    }

    private void ensure(float h) { if (y + h > H - M) newPage(); }

    private StaticLayout layout(String s, float width, float size, boolean bold, int color, Layout.Alignment al) {
        if (s == null) s = "";
        TextPaint p = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        p.setTextSize(size);
        p.setColor(color);
        p.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        return StaticLayout.Builder.obtain(s, 0, s.length(), p, Math.max(1, (int) width))
                .setAlignment(al).setLineSpacing(0f, 1.15f).build();
    }

    private void draw(StaticLayout l, float x, float top) {
        c.save();
        c.translate(x, top);
        l.draw(c);
        c.restore();
    }

    private void para(String s, float size, boolean bold, int color, Layout.Alignment al, float gap) {
        if (s == null || s.trim().isEmpty()) return;
        StaticLayout l = layout(s, CW, size, bold, color, al);
        ensure(l.getHeight());
        draw(l, M, y);
        y += l.getHeight() + gap;
    }

    private Bitmap logo(String data) {
        try {
            byte[] b;
            if (data != null && data.startsWith("data:")) {
                b = Base64.decode(data.substring(data.indexOf(',') + 1), Base64.DEFAULT);
            } else {
                InputStream in = ctx.getAssets().open("logo.png");
                ByteArrayOutputStream o = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
                in.close();
                b = o.toByteArray();
            }
            return BitmapFactory.decodeByteArray(b, 0, b.length);
        } catch (Exception e) {
            return null;
        }
    }

    private void row(String[] cells, boolean head) {
        float[] w = {252, 60, 110, 110};
        float pad = 4;
        StaticLayout[] ls = new StaticLayout[4];
        float h = 0;
        for (int i = 0; i < 4; i++) {
            ls[i] = layout(cells[i], w[i] - 2 * pad, 9.5f, head, head ? 0xFFFFFFFF : INK,
                    i == 0 ? Layout.Alignment.ALIGN_NORMAL : Layout.Alignment.ALIGN_OPPOSITE);
            h = Math.max(h, ls[i].getHeight());
        }
        h += 2 * pad;
        ensure(h);
        Paint fill = new Paint();
        fill.setColor(DARK);
        Paint line = new Paint();
        line.setStyle(Paint.Style.STROKE);
        line.setColor(0xFFCCCCCC);
        line.setStrokeWidth(0.8f);
        float x = M;
        for (int i = 0; i < 4; i++) {
            if (head) c.drawRect(x, y, x + w[i], y + h, fill);
            c.drawRect(x, y, x + w[i], y + h, line);
            draw(ls[i], x + pad, y + pad);
            x += w[i];
        }
        y += h;
    }

    private static String join(JSONArray a, String sep) throws Exception {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < a.length(); i++) {
            if (i > 0) sb.append(sep);
            sb.append(a.getString(i));
        }
        return sb.toString();
    }

    void build(JSONObject j, File out) throws Exception {
        newPage();

        // Encabezado: logo a la izquierda, datos de la empresa a la derecha
        Bitmap bmp = logo(j.optString("logo"));
        float lh = 0;
        if (bmp != null) {
            float lw = Math.min(200f, 52f * bmp.getWidth() / bmp.getHeight());
            lh = lw * bmp.getHeight() / bmp.getWidth();
            c.drawBitmap(bmp, null, new RectF(M, y, M + lw, y + lh), new Paint(Paint.FILTER_BITMAP_FLAG));
        }
        float tw = 250;
        StringBuilder det = new StringBuilder();
        String nit = j.optString("nit"), dir = j.optString("dir"), ciu = j.optString("ciudad");
        if (nit.length() > 0) det.append("NIT ").append(nit).append("\n");
        if (dir.length() > 0 || ciu.length() > 0) det.append(dir).append(dir.length() > 0 && ciu.length() > 0 ? ", " : "").append(ciu).append("\n");
        if (j.optString("tel").length() > 0) det.append("Tel. ").append(j.optString("tel")).append("\n");
        if (j.optString("mail").length() > 0) det.append(j.optString("mail")).append("\n");
        if (j.optString("web").length() > 0) det.append(j.optString("web")).append("\n");
        StaticLayout nameL = layout(j.optString("nombre"), tw, 11, true, INK, Layout.Alignment.ALIGN_OPPOSITE);
        float hh = Math.max(lh, nameL.getHeight());
        draw(nameL, W - M - tw, y);
        if (det.length() > 0) {
            StaticLayout detL = layout(det.toString().trim(), tw, 9, false, INK, Layout.Alignment.ALIGN_OPPOSITE);
            draw(detL, W - M - tw, y + nameL.getHeight());
            hh = Math.max(lh, nameL.getHeight() + detL.getHeight());
        }
        y += hh + 8;
        Paint rule = new Paint();
        rule.setColor(DARK);
        rule.setStrokeWidth(1.6f);
        c.drawLine(M, y, W - M, y, rule);
        y += 16;

        // Título, número y fecha
        para(j.optString("titulo"), 15, true, INK, Layout.Alignment.ALIGN_CENTER, 8);
        StaticLayout nl = layout("N.º " + j.optString("numero"), CW / 2f, 10, false, INK, Layout.Alignment.ALIGN_NORMAL);
        StaticLayout fl = layout("Fecha: " + j.optString("fecha"), CW / 2f, 10, false, INK, Layout.Alignment.ALIGN_OPPOSITE);
        draw(nl, M, y);
        draw(fl, M + CW / 2f, y);
        y += nl.getHeight() + 8;

        // Cliente
        JSONArray cli = j.optJSONArray("cli");
        if (cli != null && cli.length() > 0) {
            StaticLayout cl = layout("Cliente: " + join(cli, "\n"), CW - 12, 10, false, INK, Layout.Alignment.ALIGN_NORMAL);
            ensure(cl.getHeight() + 12);
            Paint box = new Paint();
            box.setStyle(Paint.Style.STROKE);
            box.setColor(0xFFCCCCCC);
            c.drawRect(M, y, M + CW, y + cl.getHeight() + 12, box);
            draw(cl, M + 6, y + 6);
            y += cl.getHeight() + 12 + 10;
        }

        para(j.optString("intro"), 10, false, INK, Layout.Alignment.ALIGN_NORMAL, 8);
        if (j.optString("alc").trim().length() > 0) {
            para("Alcance: " + j.optString("alc"), 10, false, INK, Layout.Alignment.ALIGN_NORMAL, 8);
        }

        // Tabla de ítems
        row(new String[]{"Descripción", "Cant.", "V. unit.", "Total"}, true);
        JSONArray items = j.optJSONArray("items");
        if (items != null) {
            for (int i = 0; i < items.length(); i++) {
                JSONArray it = items.getJSONArray(i);
                row(new String[]{it.getString(0), it.getString(1), it.getString(2), it.getString(3)}, false);
            }
        }
        y += 8;

        // Totales
        para("Subtotal: " + j.optString("sub"), 10, false, INK, Layout.Alignment.ALIGN_OPPOSITE, 2);
        para(j.optString("iva"), 10, false, INK, Layout.Alignment.ALIGN_OPPOSITE, 2);
        para("TOTAL: " + j.optString("total"), 12, true, INK, Layout.Alignment.ALIGN_OPPOSITE, 12);

        // Condiciones
        para("Condiciones", 11, true, INK, Layout.Alignment.ALIGN_NORMAL, 3);
        JSONArray cond = j.optJSONArray("conds");
        if (cond != null) {
            for (int i = 0; i < cond.length(); i++) {
                para("•  " + cond.getString(i), 9.5f, false, INK, Layout.Alignment.ALIGN_NORMAL, 2);
            }
        }
        y += 6;
        para("Validez de la oferta: " + j.optInt("val", 15) + " días.", 10, false, INK, Layout.Alignment.ALIGN_NORMAL, 14);
        para(j.optString("pie"), 10, false, 0xFF555555, Layout.Alignment.ALIGN_CENTER, 0);

        doc.finishPage(page);
        FileOutputStream fo = new FileOutputStream(out);
        doc.writeTo(fo);
        fo.close();
        doc.close();
    }
}
